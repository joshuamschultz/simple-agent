"""Identity — DID creation, Ed25519 keypair management, child derivation.

This module is the canonical identity primitive for all Arc packages.
Both arcagent and arcrun import from here; no Arc package implements its
own identity logic.

DID format: ``did:arc:{org}:{type}/{hash}``
  - org: deployment organization (e.g. ``default``, ``doe``)
  - type: agent role (e.g. ``executor``, ``planner``, ``child``)
  - hash: first 8 hex chars of SHA-256(public_key) — deterministic

Child identity: derived via HKDF-SHA256 from the parent secret key and a
per-spawn nonce. Children have short-lived identities that cannot be reused
across spawns.

Security:
- ASI-03: no shared credentials — each agent has a unique DID + keypair
- ASI-07: Ed25519 signing; child keys are unpredictable to observers
- Key files must have 0600 permissions (owner only); insecure perms rejected
"""

from __future__ import annotations

import hashlib
import hmac
import logging
import re
import stat
from pathlib import Path
from typing import Any

from nacl.signing import SigningKey, VerifyKey
from pydantic import BaseModel

from arctrust.classification import Classification
from arctrust.keypair import KEY_SIZE, generate_keypair

_logger = logging.getLogger("arctrust.identity")

# ---------------------------------------------------------------------------
# DID utilities
# ---------------------------------------------------------------------------


def generate_did(verify_key: VerifyKey, *, org: str, agent_type: str) -> str:
    """Derive a DID from an Ed25519 verify key.

    The hash suffix is the first 8 hex chars of SHA-256(public_key),
    making it deterministic for the same keypair.

    Args:
        verify_key: Ed25519 verify key (PyNaCl VerifyKey).
        org: Deployment organization (e.g. ``default``).
        agent_type: Agent role (e.g. ``executor``).

    Returns:
        DID string in the form ``did:arc:{org}:{type}/{hash}``.
    """
    return did_from_public_key(bytes(verify_key), org=org, agent_type=agent_type)


def did_from_public_key(public_key: bytes, *, org: str, agent_type: str) -> str:
    """Derive a DID from raw public-key bytes (algorithm-agnostic).

    Same fingerprint rule as :func:`generate_did` — ``sha256(public_key)[:8]`` —
    but takes bytes so an ECDSA-P256 (DER) operator key derives a DID exactly
    like an Ed25519 one (SPEC-037: the approval authority may sign with either).
    """
    key_hash = hashlib.sha256(public_key).hexdigest()[:8]
    return f"did:arc:{org}:{agent_type}/{key_hash}"


def did_matches_pubkey(did: str, public_key: bytes) -> bool:
    """Whether a DID's hash suffix was derived from this Ed25519 public key.

    A DID's suffix is ``sha256(public_key)[:8]`` (see :func:`generate_did`).
    This binds a DID to exactly one keypair: a caller claiming ``did`` must
    present the public key whose fingerprint matches, which — combined with a
    valid signature — proves possession of the matching private key.

    Returns False (never raises) on any malformed DID or key, so callers can
    use it as a plain boolean gate.

    Args:
        did: DID to check (``did:arc:{org}:{type}/{hash}``).
        public_key: 32-byte Ed25519 verify key to test against the DID.

    Returns:
        True iff ``sha256(public_key)[:8]`` equals the DID's hash suffix.
    """
    try:
        expected = parse_did(did)["hash"]
    except ValueError:
        return False
    actual = hashlib.sha256(bytes(public_key)).hexdigest()[:8]
    # Constant-time compare — the fingerprint is not secret, but it gates auth.
    return hmac.compare_digest(expected, actual)


def parse_did(did: str) -> dict[str, str]:
    """Parse a DID string into its component parts.

    Args:
        did: Full DID in ``did:arc:{org}:{type}/{hash}`` format.

    Returns:
        Dict with keys ``org``, ``agent_type``, ``hash``.

    Raises:
        ValueError: DID is not a valid ``did:arc:`` identifier.
    """
    if not did.startswith("did:arc:"):
        raise ValueError(f"Invalid DID: expected 'did:arc:...' prefix, got {did!r}")
    parts = did.split(":")
    if len(parts) != 4 or "/" not in parts[3]:
        raise ValueError(
            f"Malformed DID structure: {did!r}. Expected 'did:arc:{{org}}:{{type}}/{{hash}}'."
        )
    type_hash = parts[3].split("/", 1)
    return {
        "org": parts[2],
        "agent_type": type_hash[0],
        "hash": type_hash[1],
    }


def validate_did(did: str) -> str:
    """Validate a DID string; return it if valid or empty string if blank.

    An empty string is valid — it signals auto-generation. A non-empty
    string must be a well-formed ``did:arc:`` DID.

    Args:
        did: DID to validate (or empty string for auto-generation).

    Returns:
        The original DID string if valid, or empty string if blank.

    Raises:
        ValueError: DID is non-empty but malformed.
    """
    if not did:
        return ""
    if not did.startswith("did:arc:"):
        raise ValueError(
            f"Invalid DID format: {did!r}. "
            "Must be 'did:arc:{org}:{type}/{hash}' or empty for auto-generation."
        )
    parts = did.split(":")
    if len(parts) != 4 or "/" not in parts[3]:
        raise ValueError(
            f"Malformed DID structure: {did!r}. Expected 'did:arc:{{org}}:{{type}}/{{hash}}'."
        )
    return did


def _did_to_filename(did: str) -> str:
    """Convert DID to a filesystem-safe filename component."""
    return did.replace(":", "_").replace("/", "_")


# ---------------------------------------------------------------------------
# AgentIdentity
# ---------------------------------------------------------------------------


class AgentIdentity:
    """Ed25519 identity with DID and sign/verify capabilities.

    Supports both full (signing + verify) and verify-only modes.
    Verify-only instances can be constructed from a public key alone;
    full instances require a SigningKey.

    This class is the canonical agent identity for all Arc packages.
    """

    def __init__(
        self,
        did: str,
        public_key: bytes,
        _signing_key: SigningKey | None = None,
        clearance: Classification = Classification.UNCLASSIFIED,
    ) -> None:
        self.did = did
        self.public_key = public_key
        self._signing_key = _signing_key
        # Maximum classification this identity is cleared for (SPEC-038 REQ-021).
        # Resolved from operator config by arcagent at construction; immutable
        # for the session. Defaults UNCLASSIFIED (permissive for single-dev).
        self.clearance = clearance

    @property
    def can_sign(self) -> bool:
        """Whether this identity has a private key for signing."""
        return self._signing_key is not None

    @property
    def algorithm(self) -> str:
        """Signing algorithm — always Ed25519 for an agent identity.

        Present so an :class:`AgentIdentity` satisfies the ``Signer`` /
        approval-authority contract (public_key + algorithm + sign) uniformly
        with :class:`arctrust.signer.VaultSigner` (SPEC-037).
        """
        return "ed25519"

    @property
    def signing_seed(self) -> bytes:
        """Return this identity's 32-byte Ed25519 private key seed.

        The seed is what downstream signers (e.g. arcteam's ``MessageSigner``)
        need to reconstruct the signing key. Exposing it here is the single,
        auditable seam for reading private key material — callers must never
        reach ``_signing_key`` directly.

        Raises:
            ValueError: Identity has no private key (verify-only).
        """
        if self._signing_key is None:
            raise ValueError("Cannot expose signing seed: no private key available (verify-only)")
        return self._signing_key.encode()

    def sign(self, message: bytes) -> bytes:
        """Sign a message with Ed25519. Returns 64-byte signature bytes.

        Raises:
            ValueError: Identity has no private key (verify-only).
        """
        if self._signing_key is None:
            raise ValueError("Cannot sign: no private key available (verify-only identity)")
        signed = self._signing_key.sign(message)
        return signed.signature

    def verify(self, message: bytes, signature: bytes) -> bool:
        """Verify a signature against this identity's public key."""
        verify_key = VerifyKey(self.public_key)
        try:
            verify_key.verify(message, signature)
        except Exception:  # reason: fail-open — continue
            return False
        return True

    def save_keys(self, key_dir: Path) -> None:
        """Save keypair to filesystem with secure permissions.

        The key directory is created at 0700 (owner only); the key file
        is written at 0600. This is the minimum security posture for
        federal deployments.

        Raises:
            ValueError: Identity has no private key to save.
        """
        if self._signing_key is None:
            raise ValueError("Cannot save keys: no private key available")
        key_dir = Path(key_dir)
        key_dir.mkdir(parents=True, exist_ok=True)
        key_dir.chmod(0o700)

        key_file = key_dir / f"{_did_to_filename(self.did)}.key"
        key_file.write_bytes(self._signing_key.encode())
        key_file.chmod(0o600)

        pub_file = key_dir / f"{_did_to_filename(self.did)}.pub"
        pub_file.write_bytes(self.public_key)
        pub_file.chmod(0o644)

        _logger.info("Saved keypair for %s to %s", self.did, key_dir)

    @classmethod
    def load_keys(cls, did: str, key_dir: Path) -> AgentIdentity:
        """Load keypair from filesystem with integrity verification.

        Enforces 0600 permissions on the key file — insecure permissions
        indicate tampering or misconfiguration.

        Args:
            did: Full DID for the agent.
            key_dir: Directory containing the key files.

        Raises:
            ValueError: Key file missing or has insecure permissions.
        """
        key_dir = Path(key_dir)
        key_file = key_dir / f"{_did_to_filename(did)}.key"

        if not key_file.exists():
            raise ValueError(f"Key file not found: {key_file}")

        file_mode = stat.S_IMODE(key_file.stat().st_mode)
        if file_mode & (stat.S_IRWXG | stat.S_IRWXO):
            raise ValueError(
                f"Key file has insecure permissions: {oct(file_mode)}. "
                "Expected 0o600 (owner read/write only)."
            )

        signing_key = SigningKey(key_file.read_bytes())
        return cls(
            did=did,
            public_key=bytes(signing_key.verify_key),
            _signing_key=signing_key,
        )

    @classmethod
    def generate(cls, org: str, agent_type: str) -> AgentIdentity:
        """Generate a new Ed25519 keypair and derive DID.

        Args:
            org: Deployment organization.
            agent_type: Agent role.

        Returns:
            New AgentIdentity with full signing capability.
        """
        kp = generate_keypair()
        signing_key = SigningKey(kp.private_key)
        did = generate_did(signing_key.verify_key, org=org, agent_type=agent_type)
        return cls(
            did=did,
            public_key=kp.public_key,
            _signing_key=signing_key,
        )

    @classmethod
    def from_config(
        cls,
        config: Any,
        *,
        vault_resolver: Any = None,
        org: str = "default",
        agent_type: str = "executor",
        config_path: Path | None = None,
    ) -> AgentIdentity:
        """Resolve identity from config, generating and persisting if needed.

        Resolution order:
        1. ``config.did`` set → load from vault or file
        2. ``config.did`` empty → generate new keypair, save keys,
           write DID back into the config file

        The config file is the single source of truth for the agent's DID.

        Args:
            config: Object with ``did``, ``key_dir``, ``vault_path`` fields.
            vault_resolver: Optional vault backend (has ``resolve_secret``).
            org: Organization name (used when generating a new identity).
            agent_type: Agent role (used when generating a new identity).
            config_path: Path to the TOML config file for DID persistence.

        Raises:
            ValueError: Config DID is set but malformed, or key cannot be found.
        """
        key_dir = Path(config.key_dir).expanduser()
        did_to_load = validate_did(config.did)

        if did_to_load:
            if vault_resolver is not None and config.vault_path:
                try:
                    return cls._load_from_vault(did_to_load, vault_resolver, config.vault_path)
                except Exception:  # reason: fail-open — log + continue
                    _logger.warning(
                        "Vault lookup failed for %s, falling back to file",
                        did_to_load,
                    )
            return cls.load_keys(did_to_load, key_dir)

        # No DID — generate fresh identity
        identity = cls.generate(org=org, agent_type=agent_type)
        identity.save_keys(key_dir)

        if config_path is not None:
            cls._write_did_to_config(config_path, identity.did)

        _logger.info("Generated new identity: %s", identity.did)
        return identity

    @classmethod
    def _load_from_vault(cls, did: str, vault_resolver: Any, vault_path: str) -> AgentIdentity:
        """Load signing key from vault backend."""
        key_hex = vault_resolver.resolve_secret(vault_path, did)
        signing_key = SigningKey(bytes.fromhex(key_hex))
        return cls(
            did=did,
            public_key=bytes(signing_key.verify_key),
            _signing_key=signing_key,
        )

    @staticmethod
    def _write_did_to_config(config_path: Path, did: str) -> None:
        """Write generated DID back into the agent's TOML config file."""
        try:
            content = config_path.read_text(encoding="utf-8")
        except (OSError, FileNotFoundError):
            _logger.warning("Cannot read config to persist DID: %s", config_path)
            return

        updated = re.sub(
            r'^(\s*did\s*=\s*)["\'][\s]*["\']',
            rf'\1"{did}"',
            content,
            count=1,
            flags=re.MULTILINE,
        )

        if updated == content:
            _logger.warning(
                'Could not find empty did field in %s to update. Manually set: did = "%s"',
                config_path,
                did,
            )
            return

        config_path.write_text(updated, encoding="utf-8")
        _logger.info("Persisted DID to config: %s -> %s", config_path, did)


# ---------------------------------------------------------------------------
# ChildIdentity + derive_child_identity
# ---------------------------------------------------------------------------


class ChildIdentity(BaseModel):
    """Derived identity for a spawned child agent.

    Short-lived identity computed deterministically from the parent secret
    key and a per-spawn nonce. Cannot be reused across spawns.

    A Pydantic model so callers can use model_dump() / model_validate() for
    serialization (e.g. passing between processes or logging metadata).

    Attributes:
        did: DID in ``did:arc:delegate:child/{hex8}`` format.
        sk_bytes: 32-byte Ed25519 private key seed.
        ttl_s: Seconds until this identity expires.
        clearance: Child's clearance — never exceeds the parent's (SPEC-038).
    """

    did: str
    sk_bytes: bytes
    ttl_s: int
    clearance: Classification = Classification.UNCLASSIFIED


def derive_child_identity(
    *,
    parent_sk_bytes: bytes,
    spawn_id: str,
    wallclock_timeout_s: float | None = None,
    parent_clearance: Classification = Classification.UNCLASSIFIED,
    requested_clearance: Classification | None = None,
) -> ChildIdentity:
    """Derive a deterministic child identity from parent secret key and spawn id.

    Uses HKDF-SHA256 (simplified): PRK = HMAC-SHA256(salt, IKM),
    then T(1) = HMAC-SHA256(PRK, info || 0x01). The child seed is 32 bytes.

    Security:
    - ASI-03: child key is unique and unpredictable to anyone without parent SK.
    - Child key cannot be reused — spawn_id must be unique per spawn.

    Args:
        parent_sk_bytes: Parent's Ed25519 private key bytes.
        spawn_id: Per-spawn nonce (typically a UUID).
        wallclock_timeout_s: TTL in seconds. Defaults to 300 when None.

    Returns:
        ChildIdentity with derived DID and 32-byte signing key.
    """
    ttl = int(wallclock_timeout_s) if wallclock_timeout_s is not None else 300

    # Delegation narrows clearance monotone-non-increasing (SPEC-038 REQ-022):
    # a child can never out-clear its parent. A request above the parent's is
    # clamped down here; the federal hard-deny is the caller's (arcagent spawn).
    requested = requested_clearance if requested_clearance is not None else parent_clearance
    child_clearance = min(requested, parent_clearance)

    # HKDF-SHA256 expand step
    # PRK = HMAC-SHA256(salt="arc.spawn", IKM=parent_sk)
    # T(1) = HMAC-SHA256(PRK, info=spawn_id_bytes || 0x01)
    salt = b"arc.spawn"
    info = spawn_id.encode("utf-8")
    prk = hmac.new(salt, parent_sk_bytes, hashlib.sha256).digest()
    child_seed = hmac.new(prk, info + b"\x01", hashlib.sha256).digest()  # 32 bytes

    # The DID suffix is sha256(public_key)[:8] — the same key-fingerprint
    # rule as generate_did. did_matches_pubkey / verify_call enforce this
    # binding, so a suffix minted from anything else (e.g. the raw seed)
    # produces an identity whose signed calls always fail IdentityLayer.
    child_pub = bytes(SigningKey(child_seed).verify_key)
    hex_suffix = hashlib.sha256(child_pub).hexdigest()[:8]
    did = f"did:arc:delegate:child/{hex_suffix}"

    return ChildIdentity(did=did, sk_bytes=child_seed, ttl_s=ttl, clearance=child_clearance)


__all__ = [
    "KEY_SIZE",
    "AgentIdentity",
    "ChildIdentity",
    "derive_child_identity",
    "did_matches_pubkey",
    "generate_did",
    "parse_did",
    "validate_did",
]
