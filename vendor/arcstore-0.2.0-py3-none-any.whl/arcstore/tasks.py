"""``tasks`` domain — Task model + TaskStore (SPEC-056 Phase A).

Task directory over the Phase-0A mutable plane (SDD §2): collection
``"tasks"``, one row per task, atomic claim/assign so ownership can never
race (NFR-2/G3). ``MutableTaskBackend`` is the narrow seam this module
actually needs off ``StorageBackend`` — ``base.StorageBackend`` predates the
mutable plane and doesn't yet declare it (SPEC-032 migration), so a local
Protocol keeps ``TaskStore`` structurally typed without widening the shared
contract.
"""

from __future__ import annotations

import re
import unicodedata
from collections.abc import Sequence
from datetime import UTC, datetime
from typing import Any, ClassVar, Literal, Protocol

from arctrust.audit import AuditSink
from pydantic import BaseModel, ConfigDict, Field, ValidationInfo, field_validator

TaskStatus = Literal["backlog", "todo", "in_progress", "review", "done", "failed"]
# Columns an operator may move a task INTO from the board. `in_progress` is absent:
# only the dispatch claim (start_task) enters it, so a board move can never fake a run.
_OPERATOR_MOVE_STATUSES: frozenset[str] = frozenset(
    {"backlog", "todo", "review", "done", "failed"}
)
Priority = Literal["low", "medium", "high", "critical"]

# Claim ordering (SDD §2): highest priority first.
_PRIORITY_ORDER: dict[Priority, int] = {"critical": 0, "high": 1, "medium": 2, "low": 3}

_MAX_TEXT_LENGTH = 2000

# Zero-width characters used in Unicode homoglyph / split-token attacks.
_ZERO_WIDTH_RE = re.compile(r"[\u200b\u200c\u200d\u200e\u200f\ufeff]")

# Hard prompt-injection patterns (LLM01/ASI06) — always rejected, every tier,
# every construction path (agent tool, arcui, arccli), sanitized by the model
# so a caller can't forget to call it (SEC-F2/ARCH-4).
_INJECTION_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"\bignore\s+previous\b", re.IGNORECASE),
    re.compile(r"\bdisregard\b", re.IGNORECASE),
    re.compile(r"\binstead\b.*\bdo\b", re.IGNORECASE),
    re.compile(r"\bsystem:", re.IGNORECASE),
    re.compile(r"\bassistant:", re.IGNORECASE),
    re.compile(r"\bexfiltrate\b", re.IGNORECASE),
    re.compile(r"\bforget\b.*\binstructions?\b", re.IGNORECASE),
    re.compile(r"\bnew\s+instructions?\b", re.IGNORECASE),
    re.compile(r"\boverride\b", re.IGNORECASE),
    re.compile(r"<\|[a-z_]+\|>", re.IGNORECASE),  # role delimiters like <|system|>
    re.compile(r"\bbase64\b", re.IGNORECASE),
    re.compile(r"\bdo\s+not\s+follow\b", re.IGNORECASE),
)

# External-reference patterns — a URL or email in task text. Blocked at federal
# tier (the default, secure-by-default), allowed at personal/enterprise where
# pointing an agent at a repo/doc is a core use (ADR-019 tier = stringency). The
# gate is opened per-construction via ``context={"allow_external_refs": True}``;
# with no context it stays closed (fail-closed for any untrusted ingest path).
_EXTERNAL_REF_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"https?://", re.IGNORECASE),
    re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}", re.IGNORECASE),
)


def _now() -> str:
    return datetime.now(UTC).isoformat()


def _duration_seconds(started_at: str | None, completed_at: str) -> float | None:
    """Wall-clock seconds between two ISO timestamps, or None if unstarted/bad."""
    if not started_at:
        return None
    try:
        return (
            datetime.fromisoformat(completed_at) - datetime.fromisoformat(started_at)
        ).total_seconds()
    except ValueError:
        return None


def _validate_free_text(text: str, *, allow_external_refs: bool = False) -> None:
    """Reject over-length or injection-bearing free text. Raises ``ValueError``.

    NFKC folds homoglyphs (e.g. full-width Latin) to ASCII and zero-width
    separators are stripped, so neither can slip a trigger phrase past the
    regex. Used by the ``Task`` field validators — a raised ``ValueError``
    surfaces as a Pydantic ``ValidationError`` at construction.

    ``allow_external_refs`` opens the URL/email gate for personal/enterprise
    tiers; the hard injection patterns fire regardless.
    """
    if len(text) > _MAX_TEXT_LENGTH:
        raise ValueError(f"Text exceeds maximum length ({len(text)} > {_MAX_TEXT_LENGTH})")
    normalized = _ZERO_WIDTH_RE.sub("", unicodedata.normalize("NFKC", text))
    for pattern in _INJECTION_PATTERNS:
        if pattern.search(normalized):
            raise ValueError("Text rejected: possible injection pattern detected")
    if not allow_external_refs:
        for pattern in _EXTERNAL_REF_PATTERNS:
            if pattern.search(normalized):
                raise ValueError("Text rejected: URLs and emails are not allowed at this tier")


class Task(BaseModel):
    """A unit of work in the mission-control directory (SDD §2).

    Frozen — mutation always goes through ``TaskStore``, which reads the
    durable row and writes a new one; nothing holds a live ``Task`` and edits
    it in place.
    """

    model_config = ConfigDict(frozen=True)

    id: str
    title: str
    description: str = ""
    status: TaskStatus = "backlog"
    priority: Priority = "medium"
    owner_did: str | None = None
    creator_did: str
    parent_id: str | None = None
    run_id: str | None = None
    blocked_by: list[str] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)
    output: dict[str, Any] | None = None
    resolution: str | None = None
    # Lifecycle reliability (SPEC-056 Phase 1). All additive with defaults so
    # rows written before this field existed still load.
    started_at: str | None = None
    completed_at: str | None = None
    duration_seconds: float | None = None
    attempts: int = 0
    max_attempts: int = 3
    last_error: str | None = None
    # Per-task wall-clock cap for a dispatched run; None defers to the dispatch
    # config's default. A retried task is not re-dispatched before this time
    # (exponential backoff), gating the ready pool without a blocking sleep.
    timeout_seconds: float | None = None
    next_attempt_at: str | None = None
    # Operator stop signal: the dispatch loop watches this on its own in_progress
    # tasks and cancels the live run (SEC/ASI09 human-in-the-loop kill switch).
    cancel_requested: bool = False
    # Opt-in human-in-the-loop gate (SPEC-056 Phase 3, LLM06/ASI09): when set, a
    # completed task lands in ``review`` (not ``done``) until an operator
    # approves or rejects it.
    requires_review: bool = False
    # No-write-down (SEC-F3): downstream notify propagates this so a task's
    # classification bounds where it can surface. Defaults to the lowest tier.
    classification: str = "UNCLASSIFIED"
    created_at: str | None = None
    updated_at: str | None = None

    @field_validator("title", "description")
    @classmethod
    def _sanitize_free_text(cls, value: str, info: ValidationInfo) -> str:
        # Sanitize by construction (SEC-F2/ARCH-4): every path that builds a
        # Task — agent tool, arcui, arccli — is validated here, so a human path
        # can't bypass the injection/oversized/zero-width checks. The URL/email
        # gate is tier-driven via validation context; absent context = closed.
        allow_external_refs = bool((info.context or {}).get("allow_external_refs", False))
        _validate_free_text(value, allow_external_refs=allow_external_refs)
        return value


class MutableTaskBackend(Protocol):
    """The mutable-plane primitives ``TaskStore`` needs (SPEC-056 0a)."""

    async def mutable_write(
        self,
        collection: str,
        key: str,
        value: dict[str, Any],
        *,
        actor_did: str,
        sink: Any | None = None,
    ) -> None: ...

    async def mutable_read(self, collection: str, key: str) -> dict[str, Any] | None: ...

    async def mutable_delete(
        self,
        collection: str,
        key: str,
        *,
        actor_did: str,
        sink: Any | None = None,
    ) -> bool: ...

    async def mutable_query(
        self, collection: str, *, where: dict[str, Any] | None = None
    ) -> list[dict[str, Any]]: ...

    async def mutable_merge(
        self,
        collection: str,
        key: str,
        patch: dict[str, Any],
        *,
        actor_did: str,
        sink: Any | None = None,
    ) -> bool: ...

    async def update_if(
        self,
        collection: str,
        key: str,
        patch: dict[str, Any],
        where: dict[str, Any],
        *,
        actor_did: str,
        sink: Any | None = None,
        absent_where: dict[str, Any] | None = None,
    ) -> bool: ...

    async def mutable_create_batch(
        self,
        collection: str,
        entries: Sequence[tuple[str, dict[str, Any]]],
        *,
        actor_did: str,
        sink: Any | None = None,
    ) -> list[dict[str, Any]]: ...


def _is_chain_relative(active: Task, target: Task) -> bool:
    """True if ``target`` is a dependency-chain relative of ``active`` (FR-5).

    A ``blocked_by`` edge in either direction, or a shared/parent ``parent_id``,
    exempts ``target`` from the one-``in_progress``-task cap — it's the same
    piece of work, not a second independent task.
    """
    if target.id in active.blocked_by or active.id in target.blocked_by:
        return True
    if target.parent_id == active.id or active.parent_id == target.id:
        return True
    return target.parent_id is not None and target.parent_id == active.parent_id


class TaskStore:
    """Task directory over the mutable plane's ``"tasks"`` collection."""

    _COLLECTION = "tasks"

    # Deserializing a persisted row is trusted: the external-ref (URL/email)
    # policy is an ingest-time gate, not a storage invariant, so a personal-tier
    # task carrying a URL must read back everywhere regardless of the reader's
    # tier. The hard injection patterns still run on every load.
    _READ_CONTEXT: ClassVar[dict[str, bool]] = {"allow_external_refs": True}

    def __init__(self, backend: MutableTaskBackend, *, sink: AuditSink | None = None) -> None:
        self._backend = backend
        self._sink = sink

    def _load(self, row: dict[str, Any]) -> Task:
        return Task.model_validate(row, context=self._READ_CONTEXT)

    async def create(self, task: Task) -> Task:
        # A caller that didn't set status explicitly gets the SDD §4 default
        # (owned -> todo, unowned -> backlog); an explicit status is never
        # second-guessed. ``model_fields_set`` is how Pydantic distinguishes
        # "left at default" from "passed the default value on purpose".
        if "status" not in task.model_fields_set:
            derived: TaskStatus = "todo" if task.owner_did is not None else "backlog"
            task = task.model_copy(update={"status": derived})
        now = datetime.now(UTC).isoformat()
        task = task.model_copy(update={"created_at": now, "updated_at": now})
        await self._backend.mutable_write(
            self._COLLECTION,
            task.id,
            task.model_dump(mode="json"),
            actor_did=task.creator_did,
            sink=self._sink,
        )
        return task

    async def create_batch(self, tasks: Sequence[Task], *, actor_did: str) -> list[Task]:
        """Create many task rows across owners in one backend transaction.

        SPEC-061 COMP-007 — frontier materialization writes one task per
        reachable node, potentially owned by several different agents, and
        must land atomically: either every node in the batch materializes or
        none does. Idempotent on each task's own ``id`` — the caller (the
        workflow runner) is expected to derive every id deterministically
        from its ``(run_id, node_id)`` pair, so a crashed caller re-invoking
        this with the same batch gets back the rows already created instead
        of duplicating them. A task that already existed is returned as its
        current stored state, unmodified by this call; a new task is stamped
        with ``created_at``/``updated_at`` exactly like :meth:`create`.
        """
        now = datetime.now(UTC).isoformat()
        prepared: list[Task] = []
        for task in tasks:
            t = task
            if "status" not in t.model_fields_set:
                derived: TaskStatus = "todo" if t.owner_did is not None else "backlog"
                t = t.model_copy(update={"status": derived})
            t = t.model_copy(update={"created_at": now, "updated_at": now})
            prepared.append(t)
        entries = [(t.id, t.model_dump(mode="json")) for t in prepared]
        rows = await self._backend.mutable_create_batch(
            self._COLLECTION, entries, actor_did=actor_did, sink=self._sink
        )
        return [self._load(row) for row in rows]

    async def get(self, task_id: str) -> Task | None:
        raw = await self._backend.mutable_read(self._COLLECTION, task_id)
        return self._load(raw) if raw is not None else None

    async def list(self, *, status: str | None = None, owner_did: str | None = None) -> list[Task]:
        where: dict[str, Any] = {}
        if status is not None:
            where["status"] = status
        if owner_did is not None:
            where["owner_did"] = owner_did
        rows = await self._backend.mutable_query(self._COLLECTION, where=where)
        return [self._load(row) for row in rows]

    async def update(self, task_id: str, patch: dict[str, Any], *, actor_did: str) -> Task | None:
        # Atomic server-side merge (REL-F2): a read-merge-write here lets two
        # concurrent updates of disjoint fields clobber each other (last-writer
        # drops the loser's field). mutable_merge applies the patch inside one
        # SQLite step, so both land. False means the row is gone.
        merged = await self._backend.mutable_merge(
            self._COLLECTION, task_id, patch, actor_did=actor_did, sink=self._sink
        )
        if not merged:
            return None
        return await self.get(task_id)

    async def edit(
        self, task_id: str, patch: dict[str, Any], *, actor_did: str
    ) -> tuple[Task | None, str]:
        """Edit an at-rest task with a status-conditional write (REL-F1/SEC-F4).

        Refuses an ``in_progress`` task (edit is at-rest only, NFR-4) and makes
        the write conditional on the status not having changed since the read —
        so a task an owner races into ``in_progress`` between the check and the
        write is rejected, never silently clobbered by ``update``'s
        unconditional merge. Mirrors ``assign``'s snapshot-in-WHERE guard.

        Returns ``(task, "applied")`` on success, else ``(None, reason)`` where
        ``reason`` is ``"not_found"``, ``"in_progress"``, or ``"conflict"`` (the
        row raced out from under the read).
        """
        # Same write-path sanitization as ``update`` (SEC-F2/ARCH-4): a patch
        # merges raw, so keep the arcstore boundary the single sanitization
        # point rather than trusting every caller to pre-validate.
        for key in ("title", "description", "resolution"):
            value = patch.get(key)
            if isinstance(value, str):
                _validate_free_text(value)
        current = await self.get(task_id)
        if current is None:
            return None, "not_found"
        if current.status == "in_progress":
            return None, "in_progress"
        won = await self._backend.update_if(
            self._COLLECTION,
            task_id,
            patch,
            where={"status": current.status},
            actor_did=actor_did,
            sink=self._sink,
        )
        if not won:
            return None, "conflict"
        return await self.get(task_id), "applied"

    async def claim_next(self, agent_did: str) -> tuple[Task | None, str]:
        active = await self._backend.mutable_query(
            self._COLLECTION, where={"owner_did": agent_did, "status": "in_progress"}
        )
        if active:
            return self._load(active[0]), "continue_current"

        # The unowned pool is both `backlog` (freshly created, unassigned) and
        # `todo` (triaged) — a self-claim grabs from either, so the team backlog
        # is directly grabbable (no separate promotion step).
        candidates: list[Task] = []
        for status in ("backlog", "todo"):
            rows = await self._backend.mutable_query(
                self._COLLECTION, where={"status": status, "owner_did": None}
            )
            candidates.extend(self._load(row) for row in rows)
        claimable = [t for t in candidates if await self.deps_met(t)]
        claimable.sort(key=lambda t: _PRIORITY_ORDER[t.priority])

        for candidate in claimable:
            # update_if re-checks owner/status inside SQLite's own atomic
            # step, so it — not a read here followed by a write — is the gate
            # that makes two concurrent claimers resolve to exactly one
            # winner; losing just means try the next candidate. The where uses
            # the candidate's own status so a backlog and a todo task are both
            # claimable atomically. absent_where enforces the one-in_progress
            # cap in the same step (REL-F0): the active-check above and this
            # claim straddle two txns, so a second concurrent claim_next for the
            # same owner would otherwise land a second in_progress task.
            won = await self._backend.update_if(
                self._COLLECTION,
                candidate.id,
                {"owner_did": agent_did, "status": "in_progress"},
                where={"owner_did": None, "status": candidate.status},
                actor_did=agent_did,
                sink=self._sink,
                absent_where={"owner_did": agent_did, "status": "in_progress"},
            )
            if won:
                return await self.get(candidate.id), "assigned"
        return None, "no_tasks_available"

    async def delete(self, task_id: str, *, actor_did: str) -> bool:
        """Hard-delete a task from the directory. Returns True if a row existed.

        The mutable plane emits its own tamper-evident ``mutable.delete`` audit
        (AU-2), so no separate emission here — deletion is a durable operator
        action attributed to ``actor_did``.
        """
        return await self._backend.mutable_delete(
            self._COLLECTION, task_id, actor_did=actor_did, sink=self._sink
        )

    async def start_task(
        self, task_id: str, agent_did: str, *, run_id: str | None = None
    ) -> tuple[Task | None, str]:
        active_rows = await self._backend.mutable_query(
            self._COLLECTION, where={"owner_did": agent_did, "status": "in_progress"}
        )
        # Reaching the claim with an active task means this is a chain adoption
        # (an independent second task already returned continue_current below) —
        # exempt from the cap (FR-5). A claim with no active task is independent
        # and must be capped so two concurrent starts can't both land (REL-F0).
        is_chain_adoption = bool(active_rows)
        if active_rows:
            active = self._load(active_rows[0])
            target = await self.get(task_id)
            # Dependency-chain relatives are exempt from the cap (FR-5); a
            # genuinely independent second task is capped to continue_current.
            if target is None or not _is_chain_relative(active, target):
                return active, "continue_current"

        # Claim: the task is either unowned OR already assigned to this agent
        # (assign() set the owner but left it at rest) — both adopt to
        # in_progress. Snapshotting owner+status into the WHERE keeps it atomic
        # and refuses adopting a terminal or already-active task.
        target = await self.get(task_id)
        if (
            target is None
            or target.owner_did not in (None, agent_did)
            or target.status not in ("backlog", "todo")
        ):
            return None, "no_tasks_available"
        # Stamp the dispatched run's id in the SAME atomic write that claims the
        # task, so an in_progress task deterministically links its run from the
        # moment it starts (the arcui timeline joins task.run_id to the run's
        # spooled events). complete/fail patch only status+resolution, so the
        # merge preserves it through to done/failed. Each start is an attempt
        # (the retry engine counts starts); started_at anchors the duration and
        # the stuck-reclaim staleness clock, and the backoff gate is cleared now
        # that the task is actually running.
        claim: dict[str, Any] = {
            "owner_did": agent_did,
            "status": "in_progress",
            "started_at": _now(),
            "attempts": target.attempts + 1,
            "next_attempt_at": None,
        }
        if run_id is not None:
            claim["run_id"] = run_id
        won = await self._backend.update_if(
            self._COLLECTION,
            task_id,
            claim,
            where={"owner_did": target.owner_did, "status": target.status},
            actor_did=agent_did,
            sink=self._sink,
            absent_where=(
                None if is_chain_adoption else {"owner_did": agent_did, "status": "in_progress"}
            ),
        )
        if not won:
            return None, "no_tasks_available"
        return await self.get(task_id), "assigned"

    async def finish(
        self,
        task_id: str,
        *,
        status: Literal["done", "failed"],
        resolution: str,
        actor_did: str,
        output: dict[str, Any] | None = None,
        last_error: str | None = None,
    ) -> Task | None:
        """Terminal transition for an agent-driven complete/fail (SPEC-056 P1).

        Stamps ``completed_at`` and the run's ``duration_seconds`` (from
        ``started_at``) alongside status+resolution, so the board's DONE-TODAY /
        AVG-TIME metrics read off durable fields, not inferred timestamps. A
        plain merge (not status-conditional) — this is the owner completing its
        own in-flight task, not a race-prone reclaim.
        """
        current = await self.get(task_id)
        if current is None:
            return None
        now = _now()
        patch: dict[str, Any] = {
            "status": status,
            "resolution": resolution,
            "completed_at": now,
            "duration_seconds": _duration_seconds(current.started_at, now),
        }
        if output is not None:
            patch["output"] = output
        if last_error is not None:
            patch["last_error"] = last_error
        return await self.update(task_id, patch, actor_did=actor_did)

    async def requeue(
        self, task_id: str, *, actor_did: str, last_error: str, next_attempt_at: str
    ) -> Task | None:
        """Return a failed in_progress attempt to the ready pool for retry (P1).

        Status-conditional on ``in_progress`` so two reclaimers (the run's own
        finalizer and the stuck-reclaim watcher) can race and exactly one wins —
        the loser no-ops. Preserves ``attempts`` (the next ``start_task``
        increments it) and ``run_id`` (the last run stays linked until re-
        dispatch mints a new one); ``next_attempt_at`` gates re-dispatch until
        the backoff elapses. Returns the task on success, None if it raced out.
        """
        won = await self._backend.update_if(
            self._COLLECTION,
            task_id,
            {
                "status": "todo",
                "last_error": last_error,
                "next_attempt_at": next_attempt_at,
                "started_at": None,
            },
            where={"status": "in_progress"},
            actor_did=actor_did,
            sink=self._sink,
        )
        return await self.get(task_id) if won else None

    async def dead_letter(
        self, task_id: str, *, actor_did: str, resolution: str, last_error: str
    ) -> Task | None:
        """Terminally fail an in_progress task (retries exhausted or cancelled).

        Status-conditional on ``in_progress`` (same race-safety as ``requeue``);
        stamps the terminal ``completed_at``/``duration_seconds`` and clears the
        cancel flag. Returns the task on success, None if it raced out.
        """
        current = await self.get(task_id)
        if current is None:
            return None
        now = _now()
        won = await self._backend.update_if(
            self._COLLECTION,
            task_id,
            {
                "status": "failed",
                "resolution": resolution,
                "last_error": last_error,
                "completed_at": now,
                "duration_seconds": _duration_seconds(current.started_at, now),
                "cancel_requested": False,
            },
            where={"status": "in_progress"},
            actor_did=actor_did,
            sink=self._sink,
        )
        return await self.get(task_id) if won else None

    async def request_cancel(self, task_id: str, *, actor_did: str) -> Task | None:
        """Flag an in_progress task for operator cancellation (P1, ASI09).

        Only an ``in_progress`` task can be cancelled (there is no live run to
        stop otherwise), enforced by the status-conditional write. The dispatch
        loop observes the flag and stops the run. Returns the task on success,
        None if it is not running (so the route can 409) or is gone.
        """
        won = await self._backend.update_if(
            self._COLLECTION,
            task_id,
            {"cancel_requested": True},
            where={"status": "in_progress"},
            actor_did=actor_did,
            sink=self._sink,
        )
        return await self.get(task_id) if won else None

    async def set_status(self, task_id: str, new_status: str, *, actor_did: str) -> Task | None:
        """Operator board move: set an at-rest task's column. Atomic on current status.

        The human-controllable board transition (drag ``backlog`` -> ``todo`` so the
        dispatch loop will run it). ``in_progress`` is EXCLUDED as a target (only the
        dispatch claim enters it), and a task that is CURRENTLY ``in_progress`` cannot be
        board-moved, so an operator never yanks a live run out from under its owner
        (ASI08/NFR-4). The write is conditional on the current status so it no-ops rather
        than clobbering a concurrent transition. Returns the moved task, or None if the
        target is disallowed, the task is gone/running, or it raced.
        """
        if new_status not in _OPERATOR_MOVE_STATUSES:
            return None
        current = await self.get(task_id)
        if current is None or current.status == "in_progress":
            return None
        won = await self._backend.update_if(
            self._COLLECTION,
            task_id,
            {"status": new_status},
            where={"status": current.status},
            actor_did=actor_did,
            sink=self._sink,
        )
        return await self.get(task_id) if won else None

    async def unassigned(self) -> Sequence[Task]:
        """Every ownerless, non-terminal task — the routing pool (P3).

        (``Sequence`` not ``list`` — see ``children``'s note on the ``list``
        method shadowing the builtin in class-scope annotations.)
        """
        out: list[Task] = []
        for status in ("backlog", "todo"):
            rows = await self._backend.mutable_query(
                self._COLLECTION, where={"status": status, "owner_did": None}
            )
            out.extend(self._load(row) for row in rows)
        return out

    async def route(self, task_id: str, to_did: str, by_did: str) -> Task | None:
        """Assign an UNOWNED task to ``to_did`` (auto-routing, P3).

        Conditional on ``owner_did IS NULL`` so concurrent routers on different
        agents resolve to exactly one winner — the loser no-ops. Owned -> todo
        so the routed-to agent's dispatch loop then adopts it (§4). Distinct from
        ``assign`` (operator/agent handoff of an already-owned task).
        """
        won = await self._backend.update_if(
            self._COLLECTION,
            task_id,
            {"owner_did": to_did, "status": "todo"},
            where={"owner_did": None},
            actor_did=by_did,
            sink=self._sink,
        )
        return await self.get(task_id) if won else None

    async def approve_review(self, task_id: str, *, actor_did: str) -> Task | None:
        """Operator approves a task in ``review`` -> ``done`` (P3).

        Status-conditional on ``review`` (race-safe); stamps the terminal
        completed_at/duration the review gate deferred at complete time.
        """
        current = await self.get(task_id)
        if current is None:
            return None
        now = _now()
        won = await self._backend.update_if(
            self._COLLECTION,
            task_id,
            {
                "status": "done",
                "completed_at": now,
                "duration_seconds": _duration_seconds(current.started_at, now),
            },
            where={"status": "review"},
            actor_did=actor_did,
            sink=self._sink,
        )
        return await self.get(task_id) if won else None

    async def reject_review(self, task_id: str, *, actor_did: str) -> Task | None:
        """Operator rejects a task in ``review`` -> ``todo`` for re-dispatch (P3).

        Status-conditional on ``review``; clears any backoff gate so the owner's
        dispatch loop re-runs it promptly.
        """
        won = await self._backend.update_if(
            self._COLLECTION,
            task_id,
            {"status": "todo", "next_attempt_at": None},
            where={"status": "review"},
            actor_did=actor_did,
            sink=self._sink,
        )
        return await self.get(task_id) if won else None

    async def assign(self, task_id: str, to_did: str, by_did: str) -> Task | None:
        current = await self.get(task_id)
        if current is None or current.status not in ("backlog", "todo"):
            return None
        # Re-check the snapshotted status inside the atomic write: if the
        # task raced into in_progress between the read above and this write,
        # the WHERE no longer matches and the reassignment is rejected
        # rather than yanking active work out from under its owner (NFR-4).
        # Assigning moves an at-rest task into the owner's ready lane: owner set
        # AND status -> todo (an owned task is `todo`, per §4 create(owned)->todo),
        # so the assignee can then adopt it via start_task.
        won = await self._backend.update_if(
            self._COLLECTION,
            task_id,
            {"owner_did": to_did, "status": "todo"},
            where={"status": current.status},
            actor_did=by_did,
            sink=self._sink,
        )
        if not won:
            return None
        return await self.get(task_id)

    async def deps_met(self, task: Task) -> bool:
        for dep_id in task.blocked_by:
            dep = await self.get(dep_id)
            if dep is None or dep.status != "done":
                return False
        return True

    async def children(self, parent_id: str) -> Sequence[Task]:
        """Every subtask that names ``parent_id`` as its parent (any owner).

        The decomposition DAG's downward edge — used to reconcile a parent's
        terminal state from its children (SPEC-056 Phase 2). Cross-owner because
        a subtask may be reassigned, but the parent's owner still reconciles it.

        (``Sequence`` not ``list`` in the annotation only because the
        ``TaskStore.list`` method shadows the builtin ``list`` in class-scope
        annotations under ``from __future__ import annotations``.)
        """
        rows = await self._backend.mutable_query(self._COLLECTION, where={"parent_id": parent_id})
        return [self._load(row) for row in rows]

    async def deps_would_cycle(self, task_id: str, blocked_by: Sequence[str]) -> bool:
        """Whether adding ``task_id -> blocked_by`` edges would form a cycle (P2).

        A self-edge is an immediate cycle; otherwise walk the existing
        ``blocked_by`` graph forward from each proposed dependency — if any path
        reaches ``task_id``, the new edge closes a loop. Deterministic and
        bounded by the task count; used to reject an unsatisfiable dependency
        before it is ever written (a cyclic task could never become ready).
        """
        if task_id in blocked_by:
            return True
        seen: set[str] = set()
        stack: list[str] = [*blocked_by]
        while stack:
            current = stack.pop()
            if current == task_id:
                return True
            if current in seen:
                continue
            seen.add(current)
            dep = await self.get(current)
            if dep is not None:
                stack.extend(dep.blocked_by)
        return False
